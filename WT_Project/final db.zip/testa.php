
<html>
<head>
<title>Untitled Document</title>

</head>

<body>
<?php
echo date("d/m/Y")
?>
</body>
</html>
