<?php
session_start();
?>
<html>
<head>
<title>Wel come to Online Exam</title>

<link rel="stylesheet" type="text/css" href="dummy.css">
</head>

<body>
<?php
include("header.php");
include("database.php");
extract($_POST);

if(isset($submit))
{
	$rs=mysql_query("select * from mst_user where login='$loginid' and pass='$pass'");
	if(mysql_num_rows($rs)<1)
	{
		$found="N";
	}
	else
	{
		$_SESSION[login]=$loginid;
	}
}
if (isset($_SESSION[login]))
{
echo "<h1 align=center>Wel come to Online Exam</h1>";
		echo '<table width="28%"  border="0" align="center">
  <tr>
    <td width="7%" height="65" valign="bottom"><img src="HLPBUTT2.JPG" width="50" height="50" align="middle"></td>
    <td width="93%" valign="bottom" bordercolor="#0000FF"> <a href="sublist.php" class="style4">Subject for test </a></td>
  </tr>
  <tr>
    <td height="58" valign="bottom"><img src="DEGREE.JPG" width="43" height="43" align="middle"></td>
    <td valign="bottom"> <a href="result.php">Result </a></td>
  </tr>
</table>';
   
		exit;
		

}


?>
<table width="100%" border="0">
  <tr>
        <td valign="top"><form name="form1" method="post" action="">
      <table width="200" border="0">
        <tr>
          <td>Login ID </td>
          <td><input name="loginid" type="text" id="loginid2"></td>
        </tr>
        <tr>
          <td>Password</td>
          <td><input name="pass" type="password" id="pass2"></td>
        </tr>
        <tr>
          <td colspan="2">
            <?php
		  if(isset($found))
		  {
		  	echo "Invalid Username or Password";
		  }
		  ?>
          </td>
          </tr>
        <tr>
          <td colspan=2 align=center >
		  <input name="submit" type="submit" id="submit" value="Login">		  </td>
        </tr>
        <tr>
          <td colspan="2" bgcolor=orange><div align="center"><span class="style4">New User ? <a href="signup.php">Signup Free</a></span></div></td>
          </tr>
      </table>
      <div align="center">
             </div>
    </form></td>
  </tr>
</table>

</body>
</html>

