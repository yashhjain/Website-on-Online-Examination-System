<style type="text/css">
</style>
<table border="0" width="100%" cellspacing="0" cellpadding="0" >
  <tr><td width="10%"><th align="left" height=90 width=130 > 
    <a href="index.php" target="index"> <img src="scholastic.png" height=90 width=130 ></th></a>



<th height=90 align="center"><font face="Maiandra GD" size="10" color="firebrick">KJSIEIT SCHOLASTIC</font></th>

  </tr>
  <tr>
  <td>
  <?php @$_SESSION['login']; 
  error_reporting(1);
  ?>
  </td>
    <td>
	<?php
	if(isset($_SESSION['login']))
	{
	 echo "<div align=\"right\"><strong><a href=\"index.php\"> Home </a>|<a href=\"signout.php\">Signout</a></strong></div>";
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
	</td>
	
  </tr>
  
</table>
